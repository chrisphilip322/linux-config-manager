#!/bin/env bash

function print-func() {
    declare -f $1
    echo $1
}

function mkd() {
    mkdir -p $1
    cd $1
}

function which() {
    /usr/bin/which $1 2> /dev/null || type $1 2> /dev/null && return 0 || echo "Nothing named '$1' was found." >&2 && return 1
}

_list_swap_directories() {
    local IFS=$'\n'
    files=$(git ls-tree -r $(git rev-parse --abbrev-ref HEAD) --name-only)
    for f in $files
    do
        d=$(dirname -- $f)
        b=$(basename $f)
        swp=".${b}.swp"
        swp_full="${d}/${swp}"
        test -a $swp_full && readlink -f $d
    done | uniq
}

_check_for_unsaved_changes_impl() {
    local IFS=$'\n'
    if [[ $1 ]]
    then
        cd $1
    fi
    dirs_to_check=$(_list_swap_directories)
    result=$(for i in $dirs_to_check; do bash -c "cd $i && vim -r 2>&1"; done | grep "owned by: $USER" -A2 | grep "modified: YES" -B1 | grep "file name" | cut -d':' -f2 | cut -d' ' -f2)
    if [ "$result" != "" ]
    then
        echo "$(tput setaf 3)WARNING: You have unsaved changes!!!"
        echo ""
        for i in $result; do echo $i; done
        echo "$(tput sgr0)"
        return 1
    fi
}

function check_for_unsaved_changes() {
    pre-print "Checking for unsaved changes..." _check_for_unsaved_changes_impl "$@"
}

function repeat() {
    local str=$1
    local count=$2
    printf "%0.s${str}" $(seq 1 $count)
}

function pre-print() {
    local str=$1
    local cmd=$2
    printf "$str"
    local output=$($cmd "${@:3}")
    repeat \\b ${#str}
    repeat " " ${#str}
    repeat \\b ${#str}
    printf "${output}"
}

function f() {
    local target_dir="$1"
    find "$target_dir" -type d \( -path "*/node_modules" -o -path "*/venv*" -o -path "*/.tox" -o -path "*/.git" -o -path "*/.eggs" \) -prune -o -print
}

_mkvenv_impl() {
    local venv_name="$1"
    local venv_command="$2"

    if [[ -z "$venv_name" ]]
    then
        venv_name="./venv"
    fi
    if [[ -d "$venv_name" ]]
    then
        echo "There is already a folder at '$venv_name', can't create a new venv there" >&2
        return 1
    fi
    cmd="${venv_command} ${venv_name} && ${venv_name}/bin/pip install --upgrade pip && ${venv_name}/bin/pip install --upgrade setuptools"
    echo $cmd
    bash -c "$cmd"
    source "${venv_name}/bin/activate"
}

function mkvenv() {
    _mkvenv_impl "$1" "python2.7 -m virtualenv"
}

function mkvenv3() {
    _mkvenv_impl "$1" "python3 -m venv"
}

function json() {
    python2.7 -c 'import sys, json; j = json.load(sys.stdin); json.dump(j, sys.stdout, sort_keys=True, indent=4, separators=(",", ": ")); print ""'
}

function git-branch-status() {
    local RESET="$(tput sgr0)"
    local BOLD="$(tput bold)"
    local RED="$(tput setaf 9)"
    local GREEN="$(tput setaf 10)"
    local YELLOW="$(tput setaf 11)"
    local current_branch="$(git-current-branch 2> /dev/null)"
    if [[ -z "$current_branch" ]]
    then
        :
    elif [[ "$current_branch" == "master" ]]
    then
        :
    else
        local commits_ahead="$(git rev-list --count "$current_branch" ^origin/master)"
        local commits_behind="$(git rev-list --count origin/master "^$current_branch")"
        if [[ "$commits_ahead" == "0" ]]
        then
            echo -e "# ${BOLD}$current_branch${RESET} is ahead of ${BOLD}origin/master${RESET} by ${GREEN}0 commits${RESET}"
        else
            echo -e "# ${BOLD}$current_branch${RESET} is ahead of ${BOLD}origin/master${RESET} by ${YELLOW}$commits_ahead commits${RESET}"
        fi
        if [[ "$commits_behind" == "0" ]]
        then
            echo -e "# ${BOLD}$current_branch${RESET} is behind   ${BOLD}origin/master${RESET} by ${GREEN}0 commits${RESET}"
        else
            echo -e "# ${BOLD}$current_branch${RESET} is behind   ${BOLD}origin/master${RESET} by ${RED}$commits_behind commits${RESET}"
        fi
    fi
    local upstream_name
    upstream_name="$(git rev-parse --abbrev-ref --symbolic-full-name @{u} 2> /dev/null)"
    if [[ "$?" != "0" ]]
    then
        if git ls-remote --heads --exit-code origin "$current_branch" > /dev/null
        then
            echo -e "# ${RED}No upstream branch set${RESET}. Consider setting one with:"
            echo "#     git branch -u origin/${current_branch}"
        else
            echo -e "# ${YELLOW}No matching remote branch${RESET}. Consider pushing with this command to set upstream info:"
            echo "#     git push -u"
        fi
    fi
    git status
}

git-current-branch () {
    # https://github.com/sorin-ionescu/prezto/blob/master/modules/git/functions/git-branch-current
    if ! git rev-parse 2> /dev/null
    then
        echo "$0: not a repository: $PWD" >&2
        return 1
    fi
    local ref="$(git symbolic-ref HEAD 2> /dev/null)"
    if [[ -n "$ref" ]]
    then
        echo "${ref#refs/heads/}"
        return 0
    else
        return 1
    fi
}

# Source-able file to load all functions into shell
# Executable file that to run functions from not a shell
# Functions without "^function " are 'private' and not runnable externally

if [[ "${BASH_SOURCE[0]}" == "${0}" ]]
then
    if [[ $(grep "^function ${1}() {$" $0) ]]
    then
        "$@"
    elif [[ $1 ]]
    then
        echo "$1 is not a valid function"
        exit 1
    else
        echo "Pass a function name and arguments to run that function"
        exit 1
    fi
fi
